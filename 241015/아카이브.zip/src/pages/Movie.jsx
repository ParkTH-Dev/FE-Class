import React from "react";

const Movie = () => {
  return <div>Movie</div>;
};

export default Movie;
