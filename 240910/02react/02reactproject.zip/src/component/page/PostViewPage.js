import React from "react";
import { useNavigate } from "react-router-dom";
import TextInput from "../ui/TextInput";
import Button from "../ui/Button";

const PostViewPage = () => {
  const navigate = useNavigate();
  return (
    <div>
      PostViewPage
      <TextInput />
      <Button title="댓글 작성하기" onClick={() => navigate("/")} />
    </div>
  );
};

export default PostViewPage;
