import React from "react";

const PostWritePage = () => {
  return <div>PostWritePage</div>;
};

export default PostWritePage;
