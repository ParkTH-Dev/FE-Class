import React from "react";

const TextInput = () => {
  return <div>TextInput</div>;
};

export default TextInput;
