const form = document.querySelector("form");
const todoItem = document.querySelector("#todoItem");
const todos = document.querySelector(".todos");

const getLocal = () => {
  let todosContainer;

  //값을 찾아오는 역할
  if (localStorage.getItem("todosContainer") === null) todosContainer = [];
  else todosContainer = JSON.parse(localStorage.getItem("todosContainer"));
  // console.log(todosContainer);

  todosContainer.forEach((todo) => {
    const newLi = document.createElement("li");
    newLi.className = "todo";
    // newLi.classList.add("todo");

    const newSpan = document.createElement("span");
    newSpan.className = "todoContent";
    newSpan.innerText = todo;

    const completBtn = document.createElement("button");
    completBtn.className = "completBtn";
    completBtn.innerText = "완료";

    const deletBtn = document.createElement("button");
    deletBtn.className = "deletBtn";
    deletBtn.innerText = "삭제";

    // newLi.appendChild(newSpan);
    // newLi.appendChild(completBtn);
    // newLi.appendChild(deletBtn);

    newLi.append(newSpan, completBtn, deletBtn);
    savelocal(todoItem.value);
    todosContainer.appendChild(newLi);
    todoItem.value = "";
  });
};

//DOM에 있는 컨텐츠가 로드가 된다면 getLocal함수 실행시켜줘
document.addEventListener("DOMContentLoaded", getLocal);

const savelocal = (todo) => {
  let todos;

  //값을 찾아오는 역할
  if (localStorage.getItem("todos") === null) todos = [];
  else todos = JSON.parse(localStorage.getItem("todos"));

  todos.push(todo);
  // 값을 보내는 역할
  localStorage.setItem("todos", JSON.stringify(todos));

  // console.log(todos);
  todos.forEach((todo) => {
    const newLi = document.createElement("li");
    newLi.className = "todo";
    // newLi.classList.add("todo");

    const newSpan = document.createElement("span");
    newSpan.className = "todoContent";
    newSpan.innerText = todo;

    const completBtn = document.createElement("button");
    completBtn.className = "completBtn";
    completBtn.innerText = "완료";

    const deletBtn = document.createElement("button");
    deletBtn.className = "deletBtn";
    deletBtn.innerText = "삭제";

    // newLi.appendChild(newSpan);
    // newLi.appendChild(completBtn);
    // newLi.appendChild(deletBtn);

    newLi.append(newSpan, completBtn, deletBtn);
    savelocal(todoItem.value);
    todos.appendChild(newLi);
    todoItem.value = "";
  });
};

const addTodo = (e) => {
  e.preventDefault();
};

// //정석
// form.addEventListener("submit", (e) => {
//   addTodo(e);
// });

//약식
form.addEventListener("submit", addTodo);
