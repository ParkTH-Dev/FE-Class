const showPosition = (position) => {
  const { latitude, longitude } = position.coords;

  const mapContainer = document.querySelector("#map");
  const mapOption = {
    center: new kakao.maps.LatLng(latitude, longitude),
    level: 3,
  };

  const map = new kakao.maps.Map(mapContainer, mapOption);

  const positions = [
    {
      title: "이젠아카데미",
      latlng: new kakao.maps.LatLng(latitude, longitude),
    },
    {
      title: "그린아카데미",
      latlng: new kakao.maps.LatLng(37.5001513, 127.0290763),
    },
    {
      title: "SBS아카데미",
      latlng: new kakao.maps.LatLng(37.4979437, 127.0265374),
    },
    {
      title: "코리아IT",
      latlng: new kakao.maps.LatLng(37.4999467, 127.0354264),
    },
    {
      title: "하이미디어",
      latlng: new kakao.maps.LatLng(37.4987358, 127.0266779),
    },
  ];

  for (const i = 0; i < positions.length; i++) {
    // 마커 이미지의 이미지 크기 입니다
    const imageSize = new kakao.maps.Size(24, 35);

    // 마커 이미지를 생성합니다
    const markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

    // 마커를 생성합니다
    const marker = new kakao.maps.Marker({
      map: map, // 마커를 표시할 지도
      position: positions[i].latlng, // 마커를 표시할 위치
      title: positions[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
      image: markerImage, // 마커 이미지
    });
  }

  // const markerPosition = new kakao.maps.LatLng(latitude, longitude);

  // const marker = new kakao.maps.Marker({
  //   position: markerPosition,
  // });

  // marker.setMap(map);

  // const iwContent =
  //     '<div style="padding:5px;"><a href ="https://www.naver.com" target="_blank">현재위치!</a></div>',
  //   iwRemoveable = true;

  // const infowindow = new kakao.maps.InfoWindow({
  //   content: iwContent,
  //   removable: iwRemoveable,
  // });

  // kakao.maps.event.addListener(marker, "click", function () {
  //   infowindow.open(map, marker);
  // });
};

const errorPosition = (err) => {
  alert(err.message);
};

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(showPosition, errorPosition);
} else {
  alert("Geolocation을 지원하지 않는 기기입니다.");
}
