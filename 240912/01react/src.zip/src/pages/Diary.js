import React from "react";

const Diary = () => {
  return <div>Diary Page</div>;
};

export default Diary;
