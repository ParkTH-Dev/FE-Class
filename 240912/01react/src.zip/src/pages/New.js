import React from "react";

const New = () => {
  return <div>New Page</div>;
};

export default New;
