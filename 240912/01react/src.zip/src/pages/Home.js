import React from "react";
import Button from "../components/Button";

const Home = () => {
  return (
    <div>
      <Button title="버튼" type="negative" />
    </div>
  );
};

export default Home;
